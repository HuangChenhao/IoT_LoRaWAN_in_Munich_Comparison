%% Data reading and filtering part
clear; clc; close all

data = readtable('SUPREMO_ttn7_20250808.xlsx');    % Reading part
% data = readtable('lorawan_data_ttn12_EnglischGarten.xlsx');    % Reading part
% data = readtable('lorawan_data_swm12_Olympia.xlsx', 'ReadVariableNames', true);

data.ts = datetime(data.ts, 'InputFormat', 'yyyy-MM-dd''T''HH:mm:ss.SSSSSSXXX', 'TimeZone', 'UTC');

% 1. Seperate the data by its time serious
[G, ~] = findgroups(data.ts);

% 2. Only keep the max SNR and RSSI for each time-epoch
idxMaxSNR = splitapply(@(x) find(x == max(x), 1, 'first'), data.snr, G);
rowStart = splitapply(@(x) x(1), (1:height(data))', G);  % Index for each epoch
rowIdx = rowStart + idxMaxSNR - 1;
filtered_data = data(rowIdx, :);

max_rssi = splitapply(@(x) max(x), data.rssi, G);
filtered_data.rssi = max_rssi;

% 3. Counting the number of gateways
gateway_count = splitapply(@(x) numel(unique(x(~strcmp(string(x), "")))), data.gateway_eui, G);
filtered_data.gateway_count = gateway_count;

% 4. Only keep the required data
wantedVars = {'ts', 'network','spreading_factor', 'snr', 'rssi', 'gateway_count'};
filtered_data = filtered_data(:, ismember(filtered_data.Properties.VariableNames, wantedVars));

disp(head(filtered_data));

%%
figure;
% Histogram of RSSI based on its own pdf
histogram(data.rssi, ...
    'BinWidth', 1, ...
    'Normalization', 'pdf', ...
    'FaceColor', [0.2 0.6 0.8], ...
    'DisplayName', 'RSSI Histogram');
hold on;

title('Histogram of RSSI Values with Gamma Fit & Mean Value');
xlabel('RSSI (dBm)');
ylabel('Probability Density');
grid on;

% Align with Gamma-Distribution
rssi_data = data.rssi;
rssi_shift = abs(min(rssi_data)) + 1;
rssi_for_fit = rssi_data + rssi_shift;

pd = fitdist(rssi_for_fit, 'Gamma');
% disp(pd);

x_vals = linspace(min(rssi_for_fit), max(rssi_for_fit), 100);
y_vals = pdf(pd, x_vals);
x_vals_original = x_vals - rssi_shift;
plot(x_vals_original, y_vals, 'r-', 'LineWidth', 2, 'DisplayName', 'Fitted Gamma PDF');

if pd.a > 1
    rssi_mode = (pd.a - 1) * pd.b - rssi_shift
    xline(rssi_mode, '-.', 'LineWidth', 2, 'DisplayName', sprintf('Mode = %.2f dBm', rssi_mode));
end
rssi_mean=mean(filtered_data.rssi)
xline(rssi_mean, '--', 'LineWidth', 2, 'DisplayName', sprintf('Mean = %.2f dBm', rssi_mean));
legend('show');

%% LoRaWAN Evaluation Part
dt=  max(filtered_data.ts) - min(filtered_data.ts) ;
num30s_intervals = ceil(seconds(dt) / 30);

SR = length(filtered_data.ts) / num30s_intervals    % Successful Rate
Gateways = mean(filtered_data.gateway_count)        % Gateway Amount
SNR = mean(filtered_data.snr);                       % Signal Noise Rate
RSSI = mean(filtered_data.rssi);                     % Received Signal Strength Indicator

figure
subplot(2,1,1)
plot(filtered_data.ts+ hours(2), filtered_data.snr),hold on
yline(SNR,'LineWidth',1.5,'DisplayName', sprintf('Mean SNR = %.2f', SNR));
legend('show');
xlabel('Local Time (UTC+2)');
ylabel('SNR (dB)');
title('SNR over Time with Mean Line');
grid on;

subplot(2,1,2)
plot(filtered_data.ts+ hours(2), filtered_data.rssi),hold on
yline(RSSI,'LineWidth',1.5,'DisplayName', sprintf('Mean RSSI = %.2f', RSSI));
legend('show');
xlabel('Local Time (UTC+2)');
ylabel('RSSI (dB)');
title('RSSI over Time with Mean Line');
grid on;

%% Mean value based SNR*
% close all; clc
figure;
histogram(filtered_data.snr, ...
    'BinWidth', 1, ...
    'Normalization', 'pdf', ...
    'FaceColor', [0.2 0.6 0.8], ...
    'DisplayName', 'SNR Histogram');
hold on;

title('Histogram of SNR Values with Mean');
xlabel('SNR (dB)');
ylabel('Probability Density');
grid on;
snr_mean=mean(filtered_data.snr)
xline(snr_mean, 'k--', 'LineWidth', 1.5, 'DisplayName', sprintf('Mean = %.2f dB', snr_mean));
grid on;
legend('show');


%%
figure

% Histogram of RSSI based on its own pdf
histogram(filtered_data.snr, ...
    'BinWidth', 1, ...
    'Normalization', 'pdf', ...
    'FaceColor', [0.2 0.6 0.8], ...
    'DisplayName', 'RSSI Histogram');
hold on;

title('Histogram of SNR Values with Gamma Fit & Mean Value');
xlabel('SNR (dB)');
ylabel('Probability Density');
grid on;

% Align with Gamma-Distribution
rssi_data = filtered_data.snr;
rssi_shift = abs(min(rssi_data)) + 1;
rssi_for_fit = rssi_data + rssi_shift;

pd = fitdist(rssi_for_fit, 'Gamma');
% disp(pd);

x_vals = linspace(min(rssi_for_fit), max(rssi_for_fit), 100);
y_vals = pdf(pd, x_vals);
x_vals_original = x_vals - rssi_shift;
plot(x_vals_original, y_vals, 'r-', 'LineWidth', 2, 'DisplayName', 'Fitted Gamma PDF');

if pd.a > 1
    rssi_mode = (pd.a - 1) * pd.b - rssi_shift
    xline(rssi_mode, '-.', 'LineWidth', 1.5, 'DisplayName', sprintf('Mode = %.2f dB', rssi_mode));
end
xline(snr_mean, '--', 'LineWidth', 2, 'DisplayName', sprintf('Mean = %.2f dB', snr_mean));
legend('show');

%%

% Mean value based RSSI*
figure;
histogram(filtered_data.rssi, ...
    'BinWidth', 1, ...
    'Normalization', 'pdf', ...
    'FaceColor', [0.2 0.6 0.8], ...
    'DisplayName', 'SNR Histogram');
hold on;

title('Histogram of SNR Values with Mean');
xlabel('SNR (dB)');
ylabel('Probability Density');
grid on;
rssi_mean=mean(filtered_data.rssi)
xline(rssi_mean, 'k--', 'LineWidth', 1.5, 'DisplayName', sprintf('Mean = %.2f dB', rssi_mean));
grid on;
legend('show');

% Gamma-Distribution based RSSI*
% close all; clc
figure;
% Histogram of RSSI based on its own pdf
histogram(filtered_data.rssi, ...
    'BinWidth', 1, ...
    'Normalization', 'pdf', ...
    'FaceColor', [0.2 0.6 0.8], ...
    'DisplayName', 'RSSI Histogram');
hold on;

title('Histogram of RSSI Values with Gamma Fit');
xlabel('RSSI (dBm)');
ylabel('Probability Density');
grid on;

% Align with Gamma-Distribution
rssi_data = filtered_data.rssi;
rssi_shift = abs(min(rssi_data)) + 1;
rssi_for_fit = rssi_data + rssi_shift;

pd = fitdist(rssi_for_fit, 'Gamma');
% disp(pd);

x_vals = linspace(min(rssi_for_fit), max(rssi_for_fit), 100);
y_vals = pdf(pd, x_vals);
x_vals_original = x_vals - rssi_shift;
plot(x_vals_original, y_vals, 'r-', 'LineWidth', 2, 'DisplayName', 'Fitted Gamma PDF');

if pd.a > 1
    rssi_mode = (pd.a - 1) * pd.b - rssi_shift
    xline(rssi_mode, '-.', 'LineWidth', 2, 'DisplayName', sprintf('Mode = %.2f dBm', rssi_mode));
end
xline(rssi_mean, '--', 'LineWidth', 2, 'DisplayName', sprintf('Mean = %.2f dBm', rssi_mean));
legend('show');



